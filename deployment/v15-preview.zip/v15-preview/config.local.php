<?php $p=dirname(__DIR__).'/config.local.php';return is_file($p)?require $p:[];
